from flask import Flask, request, render_template
import numpy as np
import joblib

app = Flask(__name__, template_folder="templates")

# Load the trained model and scaler
try:
    model = joblib.load('xgb_regressor_model.pkl')
    print("Model loaded successfully")
    scaler = joblib.load('standard_scaler.pkl')
    print("Scaler loaded successfully")
except Exception as e:
    print("Error loading model or scaler:", e)
    model, scaler = None, None  # Prevents crashing if models are not loaded

@app.route('/')
def index():
    return render_template('input_form.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get input data from the form
        feature_names = ['14_NH4', '14_NO2', '14_NO3', '15_NH4', '15_NO2', '15_NO3', '16_NH4', '16_NO2']
        input_data = []

        for feature in feature_names:
            if feature in request.form:
                input_data.append(float(request.form[feature]))
            else:
                raise ValueError(f"Missing input: {feature}")

        # Convert to NumPy array
        input_data = np.array([input_data])

        print("Received Input Data:", input_data)  # Debugging

        # Scale the input data
        if scaler is None:
            raise ValueError("Scaler is not loaded")
        scaled_input_data = scaler.transform(input_data)
        print("Scaled Input Data:", scaled_input_data)  # Debugging

        # Perform prediction
        if model is None:
            raise ValueError("Model is not loaded")
        predictions = model.predict(scaled_input_data)

        print("Prediction Output:", predictions)  # Debugging

        # Render results
        return render_template('result.html', prediction=predictions[0])
    
    except Exception as e:
        error_message = f"An error occurred: {str(e)}"
        print(error_message)  # Print error to console
        return render_template('error.html', error_message=error_message)

if __name__ == '__main__':
    app.run(debug=True)
